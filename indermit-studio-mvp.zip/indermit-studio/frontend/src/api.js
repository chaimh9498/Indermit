const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8787";

export async function apiRequest(path, getToken, options = {}) {
  const token = await getToken();
  if (!token) throw new Error("Please sign in to continue.");

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  });

  const contentType = response.headers.get("content-type") || "";
  const body = contentType.includes("application/json")
    ? await response.json()
    : { error: await response.text() };

  if (!response.ok) {
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  return body;
}

export { API_URL };
